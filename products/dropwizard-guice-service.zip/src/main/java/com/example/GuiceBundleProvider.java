package com.example;

import com.hubspot.dropwizard.guice.GuiceBundle;

public class GuiceBundleProvider {
    public static GuiceBundle<DropwizardConfiguration> createGuiceBundle() {
        return GuiceBundle.<DropwizardConfiguration>newBuilder()
                .addModule(new ProductModule())
                .setConfigClass(DropwizardConfiguration.class)
                .build();
    }
}
