package com.example;

import com.hubspot.dropwizard.guice.GuiceBundle;
import io.dropwizard.Application;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;

public class DropwizardApplication extends Application<DropwizardConfiguration> {

    private GuiceBundle<DropwizardConfiguration> guiceBundle;

    public static void main(String[] args) throws Exception {
        new DropwizardApplication().run(args);
    }

    @Override
    public void initialize(Bootstrap<DropwizardConfiguration> bootstrap) {
        guiceBundle = GuiceBundleProvider.createGuiceBundle();
        bootstrap.addBundle(guiceBundle);
    }

    @Override
    public void run(DropwizardConfiguration configuration, Environment environment) {
        // Guice manages dependencies
    }
}
